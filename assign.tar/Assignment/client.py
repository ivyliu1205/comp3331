# Python 3
# python client.py server_IP server_port

import socket
import threading
import os
import sys
import time

# CHECK execute command
if len(sys.argv) < 3 or len(sys.argv) > 3:
    print('Please input valid serverIP and/or serverPort')
    exit(1)
else:
    HOST = sys.argv[1]
    PORT = int(sys.argv[2])

lock = threading.Lock()

def recvMsg(sock):
    while True:
        try:
            data = sock.recv(1024)
            recvData = data.decode()
            print(recvData)
        except:
            pass


def runChat():

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    t = threading.Thread(target = recvMsg, args = (sock,), daemon = True)
    t.start()

    while True:
        msg = input()
        sock.send(msg.encode())

runChat()