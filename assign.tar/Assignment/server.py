# Python 3
# python server.py server_port block_duration timeout
# ! timeout must greater than 10. 
#       Because after running each function in the main page, I leave 10 seconds to read the contents
# ! please make the timeout test be the last.
#       Because my timeout will cut the socket off directly without any warning on client side.

import socketserver
import threading
from time import strftime, localtime
import datetime
import sys
import time
import os

PORT = 0

# CHECK execute command
if len(sys.argv) < 4 or len(sys.argv) > 4:
    print('Please input valid serverPort, serverPort and timeout')
else:
    PORT = int(sys.argv[1])
    BLOCK_DURATION = sys.argv[2]
    TIMEOUT = sys.argv[3]

HOST = ''
lock = threading.Lock()

class Manager:

    def __init__(self):
        self.users = {} # {username : (socket, addr)}
        self.wrongPwd = {}  # {username : 2}
        self.userAddr = {}  # {username : (conn, addr)}
        self.offlineMessage = {}  # {username : (message1, message2)}

    ## LOG IN
    def checkUser(self, username, password, conn, addr):
        if username in self.users:
            conn.send('== Your account is already online\n'.encode())
            return None
        else:
            notexists = True
            for line in open('credentials.txt'):
                thisuid = line.split(' ')[0].strip()
                thispwd = line.split(' ')[1].strip()
                if (username == thisuid and password == thispwd):
                    #print('right username')
                    # re-initialize the wrongPwd{}
                    self.wrongPwd[username] = 0
                    conn.send('>> Log in successfully\n'.encode())
                    # if the user has offline message, then print it
                    self.printOfflineMsg(username, conn)
                    # remove logout time in recordTime.txt
                    self.removeLogout(username)
                    notexists = False
                    # adding new user
                    lock.acquire() # lock required to block thread synchronisation
                    # add address to userAddr{}
                    self.userAddr[username] = (conn, addr)
                    self.users[username] = (conn, addr)
                    lock.release() # release lock after update
                    self.sendMessageToAll(f'>>> BROADCAST MESSAGE: [{username}] is online', username)
                    return username

                elif (username == thisuid and password != thispwd):
                    notexists = False
                    if username not in self.wrongPwd:
                        conn.send(' == Wrong password\n'.encode())
                        self.wrongPwd[username] = 1
                    else:
                        self.wrongPwd[username] += 1
                        if self.wrongPwd[username] == 3:
                            conn.send(' == Your account is locked for {} seconds. Please try later.'.format(BLOCK_DURATION).encode())
                            self.wrongPwd[username] = 0
                            time.sleep(float(BLOCK_DURATION))
                        else:
                            conn.send('== Wrong password\n'.encode())
            
            if (notexists == True):
                conn.send('== Account not exists\n'.encode())
                
            return None
         
    ## LOG OUT
    def removeUser(self, username):
        # get logout time
        curr = time.strftime('%d-%m-%Y %H:%M:%S')
        self.addLogout(username, curr)
        del self.wrongPwd[username]
        lock.acquire()
        del self.users[username]
        lock.release()

        self.sendMessageToAll(f'>>> [{username}] is leave', username)

    ## BLOCK <USER>
    def blockSomeone(self, username, willBeblock):
        if (username == willBeblock):
            return False
        if (self.checkUserExists(willBeblock) == False):
            return False
        ubList = self.getBlockList(username)
        wbList = self.getBlockList(willBeblock)
        if willBeblock in ubList:
            return False
        if username in wbList:
            return False
        # add each other to their block list
        self.addNametoBlockList(username, willBeblock)
        self.addNametoBlockList(willBeblock, username)
        return True
    ## UNBLOCK <USER>
    def unblockSomeone(self, username, willBeUnblock):
        if (username == willBeUnblock):
            return False
        ubList = self.getBlockList(username)
        wbList = self.getBlockList(willBeUnblock)
        if willBeUnblock not in ubList:
            return False
        if username not in wbList:
            return False
        self.delNameInBlockList(username, willBeUnblock)
        self.delNameInBlockList(willBeUnblock, username)
        return True

    # if the username is in credentials.txt, return True; else, return False
    def checkUserExists(self, username):
        for line in open('credentials.txt'):
            thisuid = line.split(' ')[0].strip()
            if thisuid == username:
                return True
        return False

    # print [username]'s offline message
    def printOfflineMsg(self, username, conn):
        offlineList = []
        lineList = []
        for line in open('offlineMessage.txt'):
            if (line.startswith(username)):
                line.strip('\n')
                lineList = line.split(']][[')
                break
        
        for i in range(1, len(lineList)):
            offlineList.append(lineList[i])

        num = len(offlineList)
        if (num == 0):
            return
        else:
            sendStr = '\n'.join(offlineList)
            conn.send(f' >> You have {num} offline message\n\n {sendStr}'.encode())
            # sleep 10 seconds to read
            time.sleep(10)

    ## BROADCAST: send to all unblocked friends
    def sendMessageToAll(self, msg, username):
        # check online users
        for conn, addr in self.users.values():
            onlineUser = self.findUsermameByAddr(conn, addr)
            blockList = self.getBlockList(username)
            if len(blockList) == 0:
                conn.send(msg.encode())
            else:
                for blocked_friend in blockList:
                    if onlineUser != blocked_friend:
                        conn.send(msg.encode())

    ## MESSAGE: for different situation, return different answer 
    def sendMessageToOthers(self, sender, receiver, msg):
         # receiver is offline
        if self.getOfflineFriends(sender).find(receiver) != -1:
            offlineMsg = ']][[You received a message: {} from [{}] at {}\n'.format(msg, sender, datetime.datetime.now())
            self.addOfflineMsg(receiver, offlineMsg)
            return 'send offline message successfully'
        # receiver is online
        else:
            msg = ' == You received a message: {} from {}\n'.format(msg, sender)
            for conn, addr in self.users.values():
                onlineUser = self.findUsermameByAddr(conn, addr)
                if onlineUser == receiver:
                    conn.send(msg.encode())
                    break
            return 'online user'

    # add offline message to offlineMessage.txt
    def addOfflineMsg(self, username, msg):
        after = None
        with open('offlineMessage.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line.startswith(username):
                    before = line.strip('\n')
                    after = before + msg + '\n'
                if line != '\n':
                    lines.append(line)
        f.close()
        if (after != None):
            with open('offlineMessage.txt', 'w') as f:
                for line in lines:
                    if line.startswith(username):
                        f.write(after)
                    else:
                        f.write(line)
            f.close()
    # remove all offline messages of [username]
    def removeOfflineMessage(self, username):
        with open('offlineMessage.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line != '\n':
                    lines.append(line)

        with open('offlineMessage.txt', 'w') as f:
            for line in lines:
                if line.startswith(username):
                    f.write(username + '\n')
                else:
                    f.write(line)
        f.close()

    # return a string of the username of blocked friends and offline friends of [username]
    def getCannotRecvList(self, username):
        block = self.getBlockList(username)
        offline = []
        for line in open('credentials.txt'):
            user = line.split(' ')[0]
            if user not in self.users:
                offline.append(user)
        total = block + offline
        total = list(set(total))
        return ' '.join(total)

    # return a string of all online user except [username] itself and who is blocked by [username]
    def getOnlineUser(self, username):
        block = self.getBlockList(username)
        online = []
        for key, values in self.users.items():
            if key != username:
                if key not in block:
                    online.append(key)
        return ' '.join(online)

    # return a list of logout friends within [within] seconds
    def getWithinFriends(self, username, within):
        currTime = datetime.datetime.now()
        find = []
        offline = []
        block = self.getBlockList(username)
        for line in open('credentials.txt'):
            user = line.split(' ')[0]
            if user not in block:
                if user not in self.users:
                    offline.append(user)
        for each in offline:
            if (float((currTime - self.getLogoutTime(each)).seconds) <= float(within)):
                find.append(each)
        return ' '.join(each)

    # return logout time in timestamp format
    def getLogoutTime(self, username):
        for line in open('recordTime.txt'):
            if (line.startswith(username)):
                logoutStr = line.split(' ')[1]
                break
        return time.mktime(time.strptime(logoutStr, "%d-%m-%Y %H:%M:%S"))

    # return a string of all offline friends except blocked friends and [username] itself
    def getOfflineFriends(self, username):
        offline = []
        block = self.getBlockList(username)
        for line in open('credentials.txt'):
            user = line.split(' ')[0]
            if user not in block:
                if user not in self.users:
                    offline.append(user)
        return ' '.join(offline)

    ## Handle blockList.txt
    # add [addname] to the [username]'s block list
    def addNametoBlockList(self, username, addname):
        with open('blockList.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line.startswith(username):
                    before = line.strip('\n')
                if line != '\n':
                    lines.append(line)
        f.close()
        after = before + ' ' + addname
        with open('blockList.txt', 'w') as f:
            for line in lines:
                if line.startswith(username):
                    f.write(after + '\n')
                else:
                    f.write(line)
        f.close()

    # remove [delname] from [username]'s block list
    def delNameInBlockList(self, username, delname):
        with open('blockList.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line.startswith(username):
                    before = line.strip('\n')
                if line != '\n':
                    lines.append(line)
        f.close()
        beforeList = before.split(' ')
        beforeList.remove(delname)
        after = ' '.join(beforeList)
        with open('blockList.txt', 'w') as f:
            for line in lines:
                if line.startswith(username):
                    f.write(after + '\n')
                else:
                    f.write(line)
        f.close()

    # add log out time after username
    # username logouttime
    def addLogout(self, username, timetext):
        with open('recordTime.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line != '\n':
                    lines.append(line)
        f.close()
        after = username + ' ' + timetext
        with open('recordTime.txt', 'w') as f:
            for line in lines:
                if line.startswith(username):
                    f.write(after + '\n')
                else:
                    f.write(line)
        f.close()

    # remove logout time after username in recordTime.txt
    def removeLogout(self, username):
        with open('recordTime.txt', 'r') as f:
            lines = []
            for line in f.readlines():
                if line != '\n':
                    lines.append(line)
        f.close()
        after = username
        with open('recordTime.txt', 'w') as f:
            for line in lines:
                if line.startswith(username):
                    f.write(after + '\n')
                else:
                    f.write(line)
        f.close()

    # return a list to [username]'s blocked friends
    def getBlockList(self, username):
        thisline = None
        for line in open('blockList.txt', 'r'):
            if (line.startswith(username)):
                thisline = line.strip('\n')
                break
        blockList = thisline.split(' ')
        blockList.remove(username)
        return blockList

    # return (conn, addr)
    def findAddrByUsername(self, username):
        return self.userAddr[username]
    # return username
    def findUsermameByAddr(self, conn, addr):
        tple = (conn, addr)
        for key, value in self.userAddr.items():
            if value == tple:
                return key
        return None

class TCPHandler(socketserver.BaseRequestHandler):
    manager = Manager()
    serverStartime = datetime.datetime.now()

    def handle(self):
        funclist = []
        print(f'{self.client_address[0]} is connected')

        try:
            username = self.checkIdentity()
            self.runMainPage(username)
            
        except Exception as e:
            print(e)

        print(f'{self.client_address[0]} has disconnected')
        self.manager.removeUser(username)

    # return a list contains the function choosed by the client
    def runMainPage(self, username):
        print('>> Enter main page')
        while True:
            self.request.send(
 '\n \
==================================================\n \
    Please input in the following format:\n \
    -   message <user> <message>\n \
            Send <message> to <user>\n \
    -   broadcast <message>\n \
            Send <message> to all online users except blocked users\n \
    -   whoelse\n \
            Find all online users except blocked friends\n \
    -   whoelsesince <time>\n \
            Find all users who logged out within <time> seconds\n \
    -   block <user>\n \
            Block <user>\n \
    -   unblock <user>\n \
            Unblock <user>\n \
    -   logout\n \
            Log out\n \
==================================================\n \
    Enter here: '.encode()
            )
            # Set timeout
            self.request.settimeout(float(TIMEOUT))

            func_choice = self.request.recv(1024)
            func_choice = func_choice.decode().strip()
            func_choice_list = func_choice.split(' ')

            # LOG OUT
            if (func_choice_list[0] == 'logout'):
                self.manager.removeUser(username)
                self.request.send(' == Log out Successfully\n'.encode())
                self.handle()
            # BLOCK 
            elif (func_choice_list[0] == 'block'):
                # check command length
                if (len(func_choice_list) != 2):
                    self.request.send(' == Please send in "block <user>" format'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    continue

                if (self.manager.blockSomeone(username, func_choice_list[1])):
                    urblockList = ' '.join(self.manager.getBlockList(username))
                    self.request.send(f' == Block [{func_choice_list[1]}] successfully\n Here is your blocked and who blocked your list:\n    {urblockList}'.encode())
                    # sleep 10 seconds to read list
                    time.sleep(10)
                    self.runMainPage(username)
                else:
                    self.request.send(' == Invalid block. Please try again\n'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    self.runMainPage(username)
            # UNBLOCK
            elif (func_choice_list[0] == 'unblock'):
                # check command length
                if (len(func_choice_list) != 2):
                    self.request.send(' == Please send in "unblock <user>" format'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    continue

                if (self.manager.unblockSomeone(username, func_choice_list[1]) == True):
                    urblockList = ' '.join(self.manager.getBlockList(username))
                    self.request.send(f' == Unlock [{func_choice_list[1]}] successfully\n Here is your blocked and who blocked your list:\n    {urblockList}'.encode())
                    # sleep 10 seconds to read list
                    time.sleep(10)
                    self.runMainPage(username)
                else:
                    self.request.send(' == Invalid unblock. Please try again\n'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    self.runMainPage(username)
            # BROADCAST
            elif (func_choice_list[0] == 'broadcast'):
                # check command length
                if (len(func_choice_list) < 2):
                    self.request.send(' == Please send in "broadcast <message>" format'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    continue
                sendMsg = []
                for i in range(1, len(func_choice_list)):
                    sendMsg.append(func_choice_list[i])
                sendStr = ' '.join(sendMsg)
                self.manager.sendMessageToAll(f' == BROADCAST MESSAGE: {sendStr} FROM [{username}]', username)
                cannotRecvList = self.manager.getCannotRecvList(username)
                self.request.send(f' == Your message send successfully.\n Here is the list who cannot see you msg:\n {cannotRecvList}'.encode())
                # sleep 10 seconds to read list
                time.sleep(10)
            # WHOELSE
            elif (func_choice_list[0] == 'whoelse'):
                onlineuser = self.manager.getOnlineUser(username)
                self.request.send(f' == Here is the list of your online friends:\n {onlineuser}'.encode())
                # sleep 10 seconds to read list
                time.sleep(10)
            # WHOELSESINCE
            elif (func_choice_list[0] == 'whoelsesince'):
                # check command length
                if (len(func_choice_list) != 2):
                    self.request.send(' == Please send in "whoelsesince <seconds>" format'.encode())
                    # sleep 5 seconds to show the answer
                    time.sleep(5)
                    continue

                within = func_choice_list[1]
                if (float((datetime.datetime.now() - self.serverStartime).seconds) <= float(within)):
                    withinList = self.manager.getOfflineFriends(username)
                else:
                    withinList = self.manager.getWithinFriends(username, within)
                self.request.send(f' == Here is the list of your offline friends who logout within {within} seconds :\n {withinList}'.encode())
                # sleep 5 seconds to read list
                time.sleep(5)
            # MESSAGE
            elif (func_choice_list[0] == 'message'):
                # check command length
                if (len(func_choice_list) <= 2):
                    self.request.send(' == Please send in "message <user> <message>" format'.encode())
                    # sleep 3 seconds to show the answer
                    time.sleep(3)
                    continue
                sendMsg = []
                for i in range(2, len(func_choice_list)):
                    sendMsg.append(func_choice_list[i])
                sendStr = ' '.join(sendMsg)
                blockList = self.manager.getBlockList(username)
                funcAnswer = self.manager.sendMessageToOthers(username, func_choice_list[1], sendStr)
                if (self.manager.checkUserExists(func_choice_list[1]) == False):
                    self.request.send(' == Receiver is not exists. Please try again'.encode())
                elif (func_choice_list[1] in blockList):
                    self.request.send(' == Receiver is blocked. Please try again'.encode())
                elif (username == func_choice_list[1]):
                    self.request.send(' == Cannot send to yourself. Please try again'.encode())
                elif (funcAnswer == 'send offline message successfully'):
                    self.request.send(f' == Send offline message to {func_choice_list[1]} successfully.'.encode())
                elif (funcAnswer == 'online user'):
                    self.request.send(f' == Send message to {func_choice_list[1]} successfully.'.encode())
                # sleep 3 seconds to show the answer
                time.sleep(3)
            # ELSE
            else:
                self.request.send(' == Your answer is invalid. Please try again'.encode())
                # sleep 5 seconds to show the answer
                time.sleep(5)
                

        return func_choice_list

    def checkIdentity(self):
        while True:
            # Login page
            self.request.send('> Username: '.encode())
            username = self.request.recv(1024)
            username = username.decode().strip()
            self.request.send('> Password: '.encode())
            password = self.request.recv(1024)
            password = password.decode().strip()
            
            if self.manager.checkUser(username, password, self.request, self.client_address) != None:
                return username
            else:
                return self.checkIdentity()

class ChattingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass

def runServer(HOST, PORT):
    print('>> Server is ready to connect')

    try:
        server = ChattingServer((HOST, PORT), TCPHandler)
        server.serve_forever()

    except KeyboardInterrupt:
        print('\n>> End server')
        server.shutdown()
        server.server_close()

# copy all username the blockList.txt/recordTime.txt
def initializeFile(fileName):
    allusers = []
    # store all usernames in alluses[]
    for lines in open('credentials.txt'):
        thisuid = lines.split(' ')[0].strip()
        allusers.append(thisuid)
    # write all usernames to blockList.txt
    f = open(fileName, 'w')
    for user in allusers:
        f.write(user + '\n')


# initialize txt files 
if (os.path.getsize('blockList.txt') == 0):
    initializeFile('blockList.txt')
if (os.path.getsize('recordTime.txt') == 0):
    initializeFile('recordTime.txt')
if (os.path.getsize('offlineMessage.txt') == 0):
    initializeFile('offlineMessage.txt')

runServer(HOST, PORT)
